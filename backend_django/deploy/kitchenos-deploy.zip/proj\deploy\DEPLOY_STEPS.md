# Free Deployment Guide — PythonAnywhere (no GitHub)

Your deployment package is ready:
- `kitchenos-deploy.zip` (313 KB) — at `C:\Users\hp\Desktop\New folder (2)\proj\deploy\`
- `wsgi_pythonanywhere.py` — WSGI config
- `.env.production.example` — template for your environment variables

## STEP 1 — Create a PythonAnywhere account (free)
1. Go to https://www.pythonanywhere.com/registration/register/beginner/
2. Pick a **username** (you'll get `https://YOURUSERNAME.pythonanywhere.com`)
3. Use "Beginner" free plan — no card needed

## STEP 2 — Open a Bash console
1. Click **Consoles → Bash**
2. You're now in your home directory `/home/YOURUSERNAME`

## STEP 3 — Upload the ZIP
**Easiest method — direct upload:**
1. Go to **Files** tab (top menu)
3. Navigate to `/home/YOURUSERNAME`
4. Click **Upload a file** → select `kitchenos-deploy.zip`

**Then extract:**
```bash
cd ~
unzip -o kitchenos-deploy.zip -d kitchenos_app
mv kitchenos_app/proj kitchenos
ls ~/kitchenos
```

You should see: `.kilo`, `backend_django`, `deploy`, `frontend`, `SRS_analysis.md`

## STEP 4 — Create a virtualenv and install dependencies
```bash
mkvirtualenv --python=python3.11 kitchenos310
pip install -r ~/kitchenos/backend_django/requirements.txt
```

## STEP 5 — Create your production .env
```bash
cd ~/kitchenos/backend_django
nano .env
```
Paste this (replace `YOURUSERNAME` with your actual PythonAnywhere username, and `CHANGE-ME...` with a random 50-char string):
```
SECRET_KEY=CHANGE-ME-TO-A-LONG-RANDOM-STRING-min-50-chars
DEBUG=False
ALLOWED_HOST=YOURUSERNAME.pythonanywhere.com
BREVO_SMTP_HOST=smtp-relay.brevo.com
BREVO_SMTP_PORT=465
BREVO_SMTP_USER=b6dfd9001@smtp-brevo.com
BREVO_SMTP_PASSWORD=xsmtpsib-8f4478637fb37d936bc04ecc09be08413a926cc7003a68bc01f76ee33b05de3b-jUf7fw4TYFthIMDv
BREVO_FROM_EMAIL=nahomm2010@gmail.com
FRONTEND_URL=https://YOURUSERNAME.pythonanywhere.com
```
Press **Ctrl+O**, Enter, **Ctrl+X** to save.

> Generate a real secret key at https://djecrety.ir/ if you want one.

## STEP 6 — Run Django setup
```bash
cd ~/kitchenos/backend_django
python manage.py migrate
python manage.py collectstatic --noinput
python manage.py createsuperuser   # your admin account
```

## STEP 7 — Serve the frontend
The frontend is already built (`frontend/dist/`). On PythonAnywhere beginner, you can only serve Django apps — but your SPA needs to be served as static files. Easiest path:

**Option A (recommended, simplest): Copy SPA into Django static dir**
```bash
mkdir -p ~/kitchenos/backend_django/staticfiles/frontend
cp -r ~/kitchenos/frontend/dist/* ~/kitchenos/backend_django/staticfiles/frontend/
```
Your SPA will then be served at `https://YOURUSERNAME.pythonanywhere.com/static/frontend/index.html` (skip to Step 8 — it works but ugly URL).

**Option B (cleaner URL): Edit `urls.py` to serve index.html at `/`**
I'll add this for you next.

## STEP 8 — Configure the Web app
1. Go to **Web** tab → **Add a new web app**
2. Choose **Manual configuration** → **Python 3.11**
3. Set **Virtualenv** to: `/home/YOURUSERNAME/.virtualenvs/kitchenos310`
4. Set **Source code** to: `/home/YOURUSERNAME/kitchenos/backend_django`
5. Click **WSGI configuration file** → delete all content, paste:

```python
import os
import sys

path = os.path.expanduser("~/kitchenos/backend_django")
if path not in sys.path:
    sys.path.insert(0, path)

os.environ["DJANGO_SETTINGS_MODULE"] = "kitchenos.settings_prod"

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

6. **Static files** section:
   - URL: `/static/`  →  Directory: `/home/YOURUSERNAME/kitchenos/backend_django/staticfiles`
   - URL: `/media/`   →  Directory: `/home/YOURUSERNAME/kitchenos/backend_django/media`
7. Click the green **Reload** button at the top

## STEP 9 — Visit your site
Open `https://YOURUSERNAME.pythonanywhere.com/`

Done. Your site is live. Free forever (beginner plan = 1 web app, 512MB storage, your-username.pythonanywhere.com subdomain).

---

## Common issues

**"DisallowedHost" error** → your `ALLOWED_HOST` in `.env` doesn't match the URL exactly. Re-edit `.env` and click Reload.

**"ModuleNotFoundError"** → make sure the Virtualenv path in the Web tab matches exactly: `/home/YOURUSERNAME/.virtualenvs/kitchenos310`

**Frontend shows but API calls fail (CORS)** → your `.env` `FRONTEND_URL` must exactly match the deployed URL (https, no trailing slash).

**Email not sending** → free PythonAnywhere blocks SMTP outbound. Either use Brevo's HTTPS API (already in your code) or upgrade to a paid plan for SMTP.

**Forgot to set DEBUG=False** → your `.env` is the source of truth. `settings_prod.py` reads `DEBUG` from environment.

## To redeploy after code changes
```bash
cd ~/kitchenos/backend_django
git pull   # or re-upload changed files via Files tab
python manage.py migrate
python manage.py collectstatic --noinput
```
Then **Web tab → Reload**.